window.globalConfigs = {
    "GLOBAL": {
        "baseUrl": "{!API_URL}"
    }
}