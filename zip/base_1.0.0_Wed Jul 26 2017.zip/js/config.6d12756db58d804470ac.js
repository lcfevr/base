window.globalConfigs = {
    "GLOBAL": {
        "baseUrl": "{!API_URL}"
    },
    "BRAND": {
        "name": "base",
        "logo": "",
        "title": "",
        "cache": ""
    },
    "VERSION": "1.0.0",
    "PROJECT": "base"
}